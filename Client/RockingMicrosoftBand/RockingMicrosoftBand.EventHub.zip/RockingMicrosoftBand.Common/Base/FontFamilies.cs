﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;

namespace RockingMicrosoftBand.Common.Base
{
    public static class FontFamilies
    {
        public static FontFamily ArialBlack = new FontFamily("Arial Black");
        public static FontFamily CenturyGothic = new FontFamily("Century Gothic");
        public static FontFamily ComicSans = new FontFamily("Comic Sans MS");
        public static FontFamily CourierNew = new FontFamily("Courier New");
        public static FontFamily Impact = new FontFamily("Impact");
        public static FontFamily SegoeUI = new FontFamily("Segoe UI");
        public static FontFamily SegoeUISymbol = new FontFamily("Segoe UI Symbol");
        public static FontFamily SegoeWPBlack = new FontFamily("Segoe WP Black");
        public static FontFamily Stencil = new FontFamily("Stencil");
        public static FontFamily Tahoma = new FontFamily("Tahoma");
        public static FontFamily Webdings = new FontFamily("Webdings");
        public static FontFamily Wingdings = new FontFamily("Wingdings");
        public static FontFamily Wingdings2 = new FontFamily("Wingdings 2");
        public static FontFamily Wingdings3 = new FontFamily("Wingdings 3");
    }
}
