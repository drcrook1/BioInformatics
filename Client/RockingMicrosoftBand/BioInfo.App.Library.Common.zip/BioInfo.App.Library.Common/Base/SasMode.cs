﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BioInfo.App.Library.Common.Base
{
    public enum SasMode : int
    {
        None = 0,
        Aqmp = 1, 
        Http = 2
    }
}
