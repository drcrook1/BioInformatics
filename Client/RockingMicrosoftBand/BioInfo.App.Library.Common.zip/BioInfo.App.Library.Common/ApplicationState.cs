﻿using BioInfo.App.Library.Common.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace BioInfo.App.Library.Common
{
    public static class ApplicationState
    {
        public static IDispatchOnUIThread AnyDispatcher;
    }
}
