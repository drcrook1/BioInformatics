﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bioinfo.App.Library.Band.Enum
{   [Flags]
    public enum BandType : int
    {
        
        None = 0,
        Band,
        Band2

    }
}