﻿using Microsoft.Band;
using Microsoft.Band.Portable.Sensors;
using Microsoft.Band.Portable;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BioInfo.App.Library.Band
{
    public static class MicrosoftBandState
    {
        public static IBandClient BandClient;
    }
}
